import os
import zipfile
import base64

# Base64 của một file ảnh PNG hình vuông màu cam chữ G đơn giản (128x128)
# Để cho nhanh, đây là mã base64 của một file PNG cam rỗng 1x1 pixel (sẽ được tự động scale)
png_base64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXY3jP4PgfAAWgA4IEMm/6AAAAAElFTkSuQmCC"
image_data = base64.b64decode(png_base64)

ext_dir = os.path.dirname(os.path.abspath(__file__))

# 1. Tạo các file icon
for size in [16, 48, 128]:
    with open(os.path.join(ext_dir, f"icon{size}.png"), "wb") as f:
        f.write(image_data)
        
print("✅ Đã tạo thành công các file icon16.png, icon48.png, icon128.png")

# 2. Đóng gói ra file ZIP
zip_path = os.path.join(os.path.dirname(ext_dir), "GHN_Auto_Export_Extension.zip")

files_to_zip = [
    "manifest.json",
    "background.js",
    "content.js",
    "popup.html",
    "styles.css",
    "icon16.png",
    "icon48.png",
    "icon128.png"
]

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for file in files_to_zip:
        file_path = os.path.join(ext_dir, file)
        if os.path.exists(file_path):
            zipf.write(file_path, file)
            
print(f"✅ Đã đóng gói thành công file cài đặt: {zip_path}")
print("Bây giờ bạn có thể gửi file ZIP này cho bất kỳ ai để họ cài đặt!")
