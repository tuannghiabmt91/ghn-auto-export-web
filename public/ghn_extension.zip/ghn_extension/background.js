const REPORT_URLS = [
  "https://nhanh.ghn.vn/lastmile/report/backlog-lgt",
  "https://nhanh.ghn.vn/lastmile/report/backlog-rotation"
];

chrome.runtime.onInstalled.addListener(() => {
  setupDailyAlarms();
});

async function setupDailyAlarms() {
  chrome.alarms.clearAll();
  
  const data = await chrome.storage.local.get(['scheduledTimes']);
  let times = data.scheduledTimes || ["10:00", "15:00", "23:55"];
  
  console.log("GHN Auto Export: Thiết lập lịch chạy - " + times.join(", "));

  times.forEach(timeStr => {
    const [hour, minute] = timeStr.split(':').map(Number);
    createDailyAlarm(`scheduled_run_${timeStr.replace(':', '_')}`, hour, minute);
  });
}

function createDailyAlarm(name, hour, minute) {
  const now = new Date();
  let target = new Date();
  target.setHours(hour, minute, 0, 0);
  
  // Nếu giờ này đã trôi qua trong ngày hôm nay, hẹn giờ cho ngày mai
  if (target <= now) {
    target.setDate(target.getDate() + 1);
  }
  
  const delayInMinutes = (target.getTime() - now.getTime()) / 60000;
  
  // Hẹn giờ báo thức hàng ngày (1440 phút)
  chrome.alarms.create(name, { 
    delayInMinutes: delayInMinutes, 
    periodInMinutes: 1440 
  });
}

// Xử lý khi Alarm kêu
chrome.alarms.onAlarm.addListener(async (alarm) => {
  console.log("GHN Auto Export: Báo thức kêu - " + alarm.name);
  if (alarm.name.startsWith("scheduled_run_")) {
    startExportSequence();
  } else if (alarm.name === "next_report_alarm") {
    processNextReport();
  }
});

// Xử lý tin nhắn từ Popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'run_export') {
    startExportSequence();
    sendResponse({ success: true });
  } else if (request.action === 'update_alarms') {
    setupDailyAlarms();
    sendResponse({ success: true });
  }
  return true;
});

async function startExportSequence() {
  // Lưu hàng đợi vào Storage để không bị mất khi Service Worker reset
  await chrome.storage.local.set({ reportQueue: [...REPORT_URLS] });
  processNextReport();
}

async function processNextReport() {
  const data = await chrome.storage.local.get(['reportQueue']);
  let queue = data.reportQueue || [];

  if (queue.length === 0) {
    console.log("GHN Auto Export: Hàng đợi trống.");
    return;
  }

  const url = queue.shift();
  // Cập nhật lại hàng đợi mới vào Storage
  await chrome.storage.local.set({ reportQueue: queue });

  chrome.tabs.create({ url: url + "?auto_export=true", active: false });
  console.log("GHN Auto Export: Đã mở tab cho " + url);

  if (queue.length > 0) {
    // Hẹn giờ 3 phút cho báo cáo tiếp theo
    chrome.alarms.create("next_report_alarm", { delayInMinutes: 3 });
    console.log("GHN Auto Export: Đã hẹn giờ 3 phút cho báo cáo tiếp theo.");
  }
}
