// Khai báo các phần tử DOM
const statusText = document.getElementById('statusText');
const scheduleList = document.getElementById('scheduleList');
const addTimeBtn = document.getElementById('addTimeBtn');
const newTimeInput = document.getElementById('newTime');

// Load và hiển thị lịch chạy khi mở popup
loadSchedule();

async function loadSchedule() {
  const data = await chrome.storage.local.get(['scheduledTimes']);
  let times = data.scheduledTimes || ["10:00", "15:00", "23:55"];
  
  // Sắp xếp giờ tăng dần
  times.sort();
  
  renderSchedule(times);
}

function renderSchedule(times) {
  scheduleList.innerHTML = '';
  
  if (times.length === 0) {
    scheduleList.innerHTML = '<div style="font-size: 12px; color: #999; text-align: center; padding: 10px;">Chưa có lịch chạy nào</div>';
    return;
  }

  times.forEach((time, index) => {
    const item = document.createElement('div');
    item.className = 'schedule-item';
    item.innerHTML = `
      <span class="time-val">${time}</span>
      <span class="delete-btn" data-index="${index}">Xóa</span>
    `;
    scheduleList.appendChild(item);
  });

  // Gán sự kiện xóa
  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const index = e.target.getAttribute('data-index');
      deleteTime(index);
    });
  });
}

async function addTime() {
  const newTime = newTimeInput.value;
  if (!newTime) return;

  const data = await chrome.storage.local.get(['scheduledTimes']);
  let times = data.scheduledTimes || ["10:00", "15:00", "23:55"];

  if (times.includes(newTime)) {
    alert('Giờ này đã tồn tại!');
    return;
  }

  times.push(newTime);
  await chrome.storage.local.set({ scheduledTimes: times });
  
  // Thông báo cho background cập nhật báo thức
  chrome.runtime.sendMessage({ action: 'update_alarms' });
  
  loadSchedule();
}

async function deleteTime(index) {
  const data = await chrome.storage.local.get(['scheduledTimes']);
  let times = data.scheduledTimes || ["10:00", "15:00", "23:55"];

  times.splice(index, 1);
  await chrome.storage.local.set({ scheduledTimes: times });
  
  // Thông báo cho background cập nhật báo thức
  chrome.runtime.sendMessage({ action: 'update_alarms' });
  
  loadSchedule();
}

addTimeBtn.addEventListener('click', addTime);

document.getElementById('runNowBtn').addEventListener('click', () => {
  statusText.innerText = 'Đang kích hoạt...';
  statusText.style.color = '#f39c12';

  // Gửi tin nhắn tới background script để chạy ngay
  chrome.runtime.sendMessage({ action: 'run_export' }, (response) => {
    if (response && response.success) {
      statusText.innerText = 'Đã gửi yêu cầu!';
      statusText.style.color = '#27ae60';
      setTimeout(() => {
        statusText.innerText = 'Đang hoạt động';
      }, 3000);
    }
  });
});
