// Hàm tìm và nhấn nút "Tải xuống dữ liệu"
function triggerDownload() {
  console.log("GHN Auto Export: Đang tìm nút tải xuống...");
  
  // Tìm tất cả các button trên trang
  const buttons = document.querySelectorAll('button');
  let found = false;
  
  buttons.forEach(btn => {
    if (btn.innerText.includes('Tải xuống dữ liệu')) {
      console.log("GHN Auto Export: Đã tìm thấy nút. Đang nhấn...");
      btn.click();
      found = true;
    }
  });
  
  if (!found) {
    // Thử tìm theo class hoặc cấu trúc khác nếu innerText không khớp hoàn toàn
    const spanButtons = document.querySelectorAll('span');
    spanButtons.forEach(span => {
      if (span.innerText.includes('Tải xuống dữ liệu')) {
        const parentBtn = span.closest('button');
        if (parentBtn) {
          console.log("GHN Auto Export: Đã tìm thấy nút (qua span). Đang nhấn...");
          parentBtn.click();
          found = true;
        }
      }
    });
  }

  return found;
}

// Lắng nghe lệnh từ background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "click_download") {
    const success = triggerDownload();
    sendResponse({ success: success });
  }
});

// Tự động chạy nếu URL chứa tham số ?auto_export=true
if (window.location.search.includes('auto_export=true')) {
    console.log("GHN Auto Export: Đã phát hiện chế độ tự động. Đang chờ 7 giây...");
    setTimeout(() => {
        const success = triggerDownload();
        if (success) {
            console.log("GHN Auto Export: Đã thực hiện tự động thành công. Đang đóng tab...");
            // Chờ thêm 2 giây để chắc chắn lệnh đã gửi đi rồi mới đóng tab
            setTimeout(() => { window.close(); }, 2000); 
        } else {
            console.log("GHN Auto Export: Thất bại, không tìm thấy nút.");
        }
    }, 7000); // Chờ 7 giây cho trang load và cảnh báo biến mất
}
